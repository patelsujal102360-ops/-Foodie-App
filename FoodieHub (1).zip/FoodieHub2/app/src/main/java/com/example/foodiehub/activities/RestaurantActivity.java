package com.example.foodiehub.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.foodiehub.R;
import com.example.foodiehub.adapters.FoodAdapter;
import com.example.foodiehub.models.Food;
import com.example.foodiehub.utils.CartManager;

import java.util.ArrayList;

public class RestaurantActivity extends AppCompatActivity {

    RecyclerView recyclerFoods;
    FoodAdapter adapter;
    ArrayList<Food> foodList;
    TextView tvRestaurantName, tvCartCount, tvCartPrice;
    ImageView btnBack;
    LinearLayout llViewCart;
    String name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_restaurant);

        tvRestaurantName = findViewById(R.id.tvRestaurantName);
        btnBack = findViewById(R.id.btnBack);
        recyclerFoods = findViewById(R.id.recyclerFoods);
        llViewCart = findViewById(R.id.llViewCart);
        tvCartCount = findViewById(R.id.tvCartCount);
        tvCartPrice = findViewById(R.id.tvCartPrice);

        btnBack.setOnClickListener(v -> finish());

        name = getIntent().getStringExtra("restaurant_name");
        if (name != null) {
            tvRestaurantName.setText(name);
        }

        recyclerFoods.setLayoutManager(new LinearLayoutManager(this));

        foodList = new ArrayList<>();
        
        if (name != null && name.equals("Tea Post")) {
            // TEA POST MENU
            String chaiImg = "https://images.pexels.com/photos/31141291/pexels-photo-31141291.jpeg?auto=compress&cs=tinysrgb&w=600";
            String fchaiImg = "https://images.pexels.com/photos/36326292/pexels-photo-36326292.jpeg?auto=compress&cs=tinysrgb&w=600";
            String greenTeaImg = "https://images.pexels.com/photos/1417945/pexels-photo-1417945.jpeg?auto=compress&cs=tinysrgb&w=600";
            String blackTeaImg = "https://images.unsplash.com/photo-1571934811356-5cc061b6821f?auto=compress&cs=tinysrgb&w=600";
            String lemonTeaImg = "https://images.unsplash.com/photo-1556679343-c7306c1976bc?auto=compress&cs=tinysrgb&w=600";
            String blackCoffeeImg = "https://images.unsplash.com/photo-1611162458324-aae1eb4129a4?auto=compress&cs=tinysrgb&w=600";
            String hazelnutImg = "https://images.unsplash.com/photo-1633040244595-19a2f7b24512?auto=compress&cs=tinysrgb&w=600";
            String cappuccinoImg = "https://images.unsplash.com/photo-1534778101976-62847782c213?w=500&q=80";
            String hazelnutmImg = "hhttps://images.unsplash.com/photo-1553787499-6f9133860278?w=500&q=80";
            String hmilkImg = "https://images.pexels.com/photos/10407042/pexels-photo-10407042.jpeg?auto=compress&cs=tinysrgb&w=600";

            String hotCoffeeImg = "https://images.pexels.com/photos/312418/pexels-photo-312418.jpeg?auto=compress&cs=tinysrgb&w=600";
            String coldCoffeeImg = "https://images.unsplash.com/photo-1517701604599-bb29b565090c?w=500&q=80";
            String cmilkImg = "https://images.pexels.com/photos/34541593/pexels-photo-34541593.jpeg?auto=compress&cs=tinysrgb&w=600";
            String milkShakesImg = "https://images.unsplash.com/photo-1546173159-315724a31696?w=500&q=80";
            String omilkShakesImg = "https://images.unsplash.com/photo-1572490122747-3968b75cc699?w=500&q=80";
            String cmilkShakesImg = "https://images.unsplash.com/photo-1517701604599-bb29b565090c?w=500&q=80";
            String smilkShakesImg = "https://images.unsplash.com/photo-1611928237590-087afc90c6fd?w=500&q=80";

            String psnackImg = "https://images.pexels.com/photos/13063292/pexels-photo-13063292.jpeg?auto=compress&cs=tinysrgb&w=600";
            String snackImg = "https://images.pexels.com/photos/37153389/pexels-photo-37153389.jpeg?auto=compress&cs=tinysrgb&w=600";
            String csnackImg = "https://images.pexels.com/photos/6262227/pexels-photo-6262227.jpeg?auto=compress&cs=tinysrgb&w=600";

            String puffImg = "https://images.unsplash.com/photo-1682263167429-0dbcf2c1e127?auto=compress&cs=tinysrgb&w=600";

            String friesImg = "https://images.unsplash.com/photo-1630384060421-cb20d0e0649d?w=500&q=80";
            String pfriesImg = "https://images.unsplash.com/photo-1576107232684-1279f390859f?w=500&q=80";
            String cfriesImg = "https://images.pexels.com/photos/7594963/pexels-photo-7594963.jpeg";


            foodList.add(new Food(1, "Classic Tea (Full)", 15, "CHAI", chaiImg));
            foodList.add(new Food(2, "Classic Tea (Half)", 10, "CHAI", fchaiImg));
            foodList.add(new Food(3, "Indian Masala", 20, "CHAI", chaiImg));

            foodList.add(new Food(9, "Black Tea", 15, "CHAI WITHOUT MILK", blackTeaImg));
            foodList.add(new Food(10, "Lemon", 20, "CHAI WITHOUT MILK", lemonTeaImg));
            foodList.add(new Food(11, "Green Tea", 25, "CHAI WITHOUT MILK", greenTeaImg));

            foodList.add(new Food(13, "Black Coffee", 25, "HOT COFFEE", blackCoffeeImg));
            foodList.add(new Food(14, "Hot Coffee", 30, "HOT COFFEE", hotCoffeeImg));
            foodList.add(new Food(16, "Filter Coffee", 35, "HOT COFFEE", hotCoffeeImg));
            foodList.add(new Food(17, "Hazelnut Coffee", 40, "HOT COFFEE", hazelnutImg));

            foodList.add(new Food(18, "Classic Cold Coffee", 120, "COLD COFFEE", coldCoffeeImg));
            foodList.add(new Food(19, "Cappuccino", 130, "COLD COFFEE", cappuccinoImg));
            foodList.add(new Food(21, "Hazelnut", 130, "COLD COFFEE", hazelnutmImg));

            foodList.add(new Food(32, "Hot Bournvita", 30, "MILK", hmilkImg));
            foodList.add(new Food(33, "Cold Cocoa", 45, "MILK", cmilkImg));
            foodList.add(new Food(34, "Hot Chocolate", 45, "MILK", hmilkImg));
            foodList.add(new Food(35, "Cold Bournvita", 100, "MILK", cmilkImg));

            foodList.add(new Food(36, "Strawberry", 120, "MILK SHAKES", smilkShakesImg));
            foodList.add(new Food(37, "Chocolate", 125, "MILK SHAKES", cmilkShakesImg));
            foodList.add(new Food(38, "Oreo", 130, "MILK SHAKES", omilkShakesImg));
            foodList.add(new Food(39, "Mango", 140, "MILK SHAKES", milkShakesImg));

            foodList.add(new Food(43, "Poha", 15, "DESI NASTA", psnackImg));
            foodList.add(new Food(47, "Samosa", 40, "DESI NASTA", snackImg));
            foodList.add(new Food(48, "Samosa Chat", 50, "DESI NASTA", csnackImg));

            foodList.add(new Food(70, "Veg Puff", 40, "PUFF", puffImg));
            foodList.add(new Food(71, "Peri Peri Puff", 50, "PUFF", puffImg));
            foodList.add(new Food(72, "Cheese Puff", 60, "PUFF", puffImg));

            foodList.add(new Food(74, "Classic Fries", 65, "FRENCH FRIES", friesImg));
            foodList.add(new Food(75, "Peri Peri Fries", 110, "FRENCH FRIES", pfriesImg));
            foodList.add(new Food(76, "Deep Cheese", 125, "FRENCH FRIES", cfriesImg));
        } else if (name != null && name.equals("Mr. Kutchhi")) {
            // MR. KUTCHHI MENU
            String dabeliImg = "https://images.pexels.com/photos/10675801/pexels-photo-10675801.jpeg?auto=compress&cs=tinysrgb&w=600";
            String cheeseDabeliImg = "https://images.pexels.com/photos/4637819/pexels-photo-4637819.jpeg?auto=compress&cs=tinysrgb&w=600";
            String vadapavImg = "https://images.pexels.com/photos/17433337/pexels-photo-17433337.jpeg?auto=compress&cs=tinysrgb&w=600";
            String cheeseVadapavImg = "https://images.pexels.com/photos/36926106/pexels-photo-36926106.jpeg?auto=compress&cs=tinysrgb&w=600";
            String masalaPavImg = "https://images.pexels.com/photos/36925852/pexels-photo-36925852.jpeg?auto=compress&cs=tinysrgb&w=600";

            foodList.add(new Food(201, "Butter Cheese Dabeli (amul)", 116, "Kutchhi Dabeli", cheeseDabeliImg));
            foodList.add(new Food(203, "Authentic Kutchi Dabeli (non Fried)", 50, "Kutchhi Dabeli", dabeliImg));
            foodList.add(new Food(204, "Mr. Kutchi Special Dabeli", 166, "Kutchhi Dabeli", dabeliImg));
            foodList.add(new Food(205, "Butter Dabeli (amul)", 66, "Kutchhi Dabeli", dabeliImg));
            foodList.add(new Food(206, "Butter Cheese Garlic Dabeli", 124, "Kutchhi Dabeli", cheeseDabeliImg));
            foodList.add(new Food(207, "Butter Garlic Dabeli", 83, "Kutchhi Dabeli", dabeliImg));
            foodList.add(new Food(208, "Kutchi Dabeli (oil Fry)", 50, "Kutchhi Dabeli", dabeliImg));
            foodList.add(new Food(209, "Fruit Jam Dabeli", 58, "Kutchhi Dabeli", dabeliImg));

            foodList.add(new Food(210, "Butter Garlic Cheese Vadapav", 141, "Vadapav", cheeseVadapavImg));
            foodList.add(new Food(211, "Butter Cheese Vada Pav", 133, "Vadapav", cheeseVadapavImg));
            foodList.add(new Food(212, "Butter Garlic Vadapav", 100, "Vadapav", vadapavImg));
            foodList.add(new Food(213, "Butter Vada Pav (amul)", 83, "Vadapav", vadapavImg));
            foodList.add(new Food(214, "Oil Fry Vadapav", 50, "Vadapav", vadapavImg));
            foodList.add(new Food(215, "Bombay Vada Pav", 50, "Vadapav", vadapavImg));

            foodList.add(new Food(224, "Butter Masala Pav", 50, "Masala Pav", masalaPavImg));
            foodList.add(new Food(225, "Masala Pav", 33, "Masala Pav", masalaPavImg));

        } else if (name != null && name.equals("Keventers - Milkshakes")) {
            // KEVENTERS MENU
            foodList.add(new Food(301, "Classic Vanilla Shake", 149, "MILKSHAKES", "https://plus.unsplash.com/premium_photo-1695035006916-bb85c139c70c?w=500&q=80"));
            foodList.add(new Food(302, "Chocolate Oreo Shake", 189, "MILKSHAKES", "https://images.unsplash.com/photo-1572490122747-3968b75cc699?w=500&q=80"));
            foodList.add(new Food(303, "Strawberry Smooth", 169, "MILKSHAKES", "https://images.unsplash.com/photo-1611928237590-087afc90c6fd?w=500&q=80"));
            foodList.add(new Food(304, "Cold Coffee Gold", 159, "MILKSHAKES", "https://images.unsplash.com/photo-1517701604599-bb29b565090c?w=500&q=80"));
            foodList.add(new Food(305, "Mango Delight Shake", 179, "MILKSHAKES", "https://images.unsplash.com/photo-1546173159-315724a31696?w=500&q=80"));
            foodList.add(new Food(306, "KitKat Break Shake", 199, "MILKSHAKES", "https://images.unsplash.com/photo-1767114915915-4433437ac280?w=500&q=80"));

            foodList.add(new Food(307, "Virgin Mojito", 129, "MOCKTAILS", "https://images.unsplash.com/photo-1513558161293-cdaf765ed2fd?w=500&q=80"));
            foodList.add(new Food(308, "Blue Lagoon", 139, "MOCKTAILS", "https://images.unsplash.com/photo-1642048162670-0ca78a159483?w=500&q=80"));
            foodList.add(new Food(309, "Watermelon Slush", 149, "MOCKTAILS", "https://images.unsplash.com/photo-1536935338788-846bb9981813?w=500&q=80"));
            foodList.add(new Food(310, "Green Apple Soda", 129, "MOCKTAILS", "https://images.unsplash.com/photo-1556679343-c7306c1976bc?w=500&q=80"));
            foodList.add(new Food(311, "Fruit Punch Mocktail", 159, "MOCKTAILS", "https://images.unsplash.com/photo-1628370797114-bf8c92bab5f0?w=500&q=80"));
        } else if (name != null && name.equals("Baba Budan Coffee")) {
            //BABA BUDAN COFFEE MENU
            foodList.add(new Food(101, "Cafe latte", 249, "Drinks", "https://images.unsplash.com/photo-1541167760496-1628856ab772?w=500&q=80"));
            foodList.add(new Food(102, "Vietnamese Coffee", 275, "Drinks", "https://images.unsplash.com/photo-1664515725366-e8328e9dc834?w=500&q=80"));
            foodList.add(new Food(103, "Espresso Tonic Coffee", 275, "Drinks", "https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?w=500&q=80"));
            foodList.add(new Food(104, "Cappuccino", 249, "Drinks", "https://images.unsplash.com/photo-1534778101976-62847782c213?w=500&q=80"));
            foodList.add(new Food(105, "Classic Cold Coffee", 249, "Drinks", "https://images.unsplash.com/photo-1517701604599-bb29b565090c?w=500&q=80"));
            foodList.add(new Food(106, "Hot Chocolate", 249, "Drinks", "https://images.unsplash.com/photo-1557772747-77ffbcf6b117?w=500&q=80"));
            foodList.add(new Food(107, "Iced Latte", 249, "Drinks", "https://images.unsplash.com/photo-1461023058943-07fcbe16d735?w=500&q=80"));
            foodList.add(new Food(108, "Nutella Hazelnut Cold Coffee", 329, "Drinks", "https://images.unsplash.com/photo-1572490122747-3968b75cc699?w=500&q=80"));
            foodList.add(new Food(109, "Biscoff Cold Coffee", 249, "Drinks", "https://images.unsplash.com/photo-1625732224706-60635233030a?w=500&q=80"));

            foodList.add(new Food(110, "Fries", 149, "Snacks", "https://images.unsplash.com/photo-1630384060421-cb20d0e0649d?w=500&q=80"));
            foodList.add(new Food(111, "Cheesy Fries", 199, "Snacks", "https://images.unsplash.com/photo-1585109649139-366815a0d713?w=500&q=80"));
            foodList.add(new Food(112, "Cheesy Nachos", 249, "Snacks", "https://images.unsplash.com/photo-1513456852971-30c0b8199d4d?w=500&q=80"));
            foodList.add(new Food(113, "Peri Peri Fries", 179, "Snacks", "https://images.unsplash.com/photo-1576107232684-1279f390859f?w=500&q=80"));
            foodList.add(new Food(114, "Loaded Nachos", 279, "Snacks", "https://images.unsplash.com/photo-1586511925558-a4c6376fe65f?w=500&q=80"));
            foodList.add(new Food(115, "Cheese Garlic Bread", 299, "Snacks", "https://images.unsplash.com/photo-1619535860434-ba1d8fa12536?w=500&q=80"));
            foodList.add(new Food(116, "Korean Bun", 349, "Snacks", "https://images.unsplash.com/photo-1771397540336-1a889447bf5b?w=500&q=80"));

            foodList.add(new Food(117, "Mac n Cheese Pasta", 399, "Pasta", "https://images.unsplash.com/photo-1702827761984-205e57a3a633?w=500&q=80"));
            foodList.add(new Food(118, "Pesto Cheese Pasta", 459, "Pasta", "https://plus.unsplash.com/premium_photo-1661293863488-4bed6c84c77a?w=500&q=80"));
            foodList.add(new Food(119, "Penne Arrabiata Pasta", 399, "Pasta", "https://images.unsplash.com/photo-1621996346565-e3dbc646d9a9?w=500&q=80"));

            foodList.add(new Food(120, "Margherita Pizza", 399, "Pizza", "https://images.unsplash.com/photo-1574071318508-1cdbab80d002?w=500&q=80"));
            foodList.add(new Food(121, "Tandoori Pizza", 429, "Pizza", "https://images.unsplash.com/photo-1594007654729-407eedc4be65?w=500&q=80"));
            foodList.add(new Food(122, "Pesto Pizza", 449, "Pizza", "https://images.unsplash.com/photo-1593560708920-61dd98c46a4e?w=500&q=80"));
            foodList.add(new Food(123, "Cheese n corn Pizza", 439, "Pizza", "https://images.unsplash.com/photo-1513104890138-7c749659a591?w=500&q=80"));
        }

        adapter = new FoodAdapter(this, foodList);
        adapter.setOnCartChangedListener(this::updateCartUI);
        recyclerFoods.setAdapter(adapter);

        llViewCart.setOnClickListener(v -> startActivity(new Intent(RestaurantActivity.this, CartActivity.class)));

        updateCartUI();
    }

    private void updateCartUI() {
        int count = CartManager.getInstance().getCartCount();
        if (count > 0) {
            llViewCart.setVisibility(View.VISIBLE);
            tvCartCount.setText(getResources().getQuantityString(R.plurals.cart_items_count, count, count));
            tvCartPrice.setText(getString(R.string.cart_price, CartManager.getInstance().getTotalPrice()));
        } else {
            llViewCart.setVisibility(View.GONE);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateCartUI();
    }
}
