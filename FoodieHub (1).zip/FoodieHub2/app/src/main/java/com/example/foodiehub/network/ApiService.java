package com.example.foodiehub.network;

import com.example.foodiehub.models.Food;
import com.example.foodiehub.models.Restaurant;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface ApiService {

    // Get all restaurants
    @GET("restaurants")
    Call<List<Restaurant>> getRestaurants();

    // Get foods of a restaurant
    @GET("foods")
    Call<List<Food>> getFoods(@Query("restaurant_id") int restaurantId);

}