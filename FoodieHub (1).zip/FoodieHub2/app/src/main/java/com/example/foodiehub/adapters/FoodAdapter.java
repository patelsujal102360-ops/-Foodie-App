package com.example.foodiehub.adapters;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.foodiehub.R;
import com.example.foodiehub.activities.FoodDetailActivity;
import com.example.foodiehub.models.Food;
import com.example.foodiehub.utils.CartManager;

import java.util.ArrayList;

public class FoodAdapter extends RecyclerView.Adapter<FoodAdapter.ViewHolder> {

    Context context;
    ArrayList<Food> foodList;
    OnCartChangedListener cartListener;

    public interface OnCartChangedListener {
        void onCartChanged();
    }

    public FoodAdapter(Context context, ArrayList<Food> foodList) {
        this.context = context;
        this.foodList = foodList;
    }

    public void setOnCartChangedListener(OnCartChangedListener listener) {
        this.cartListener = listener;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        ImageView image, ivVeg;
        TextView name, price, description, categoryHeader, tvQuantity, btnMinus, btnPlus, tvAdd;
        View btnAdd, layoutQuantity;

        public ViewHolder(View itemView) {
            super(itemView);

            image = itemView.findViewById(R.id.foodImage);
            name = itemView.findViewById(R.id.foodName);
            price = itemView.findViewById(R.id.foodPrice);
            description = itemView.findViewById(R.id.foodDescription);
            ivVeg = itemView.findViewById(R.id.ivVeg);
            categoryHeader = itemView.findViewById(R.id.tvCategoryHeader);
            btnAdd = itemView.findViewById(R.id.btnAdd);
            tvAdd = itemView.findViewById(R.id.tvAdd);
            layoutQuantity = itemView.findViewById(R.id.layoutQuantity);
            tvQuantity = itemView.findViewById(R.id.tvQuantity);
            btnMinus = itemView.findViewById(R.id.btnMinus);
            btnPlus = itemView.findViewById(R.id.btnPlus);
        }
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_food, parent, false);
        return new ViewHolder(view);
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        Food food = foodList.get(position);

        // Category header logic: Show if first item or if category changes
        if (position == 0 || !food.getCategory().equals(foodList.get(position - 1).getCategory())) {
            holder.categoryHeader.setVisibility(View.VISIBLE);
            holder.categoryHeader.setText(food.getCategory());
        } else {
            holder.categoryHeader.setVisibility(View.GONE);
        }

        holder.name.setText(food.getName());
        holder.price.setText("₹" + food.getPrice());
        holder.description.setText(food.getDescription());
        
        holder.ivVeg.setVisibility(food.isVeg() ? View.VISIBLE : View.GONE);

        updateQuantityUI(holder, food);

        Glide.with(context)
                .load(food.getImage())
                .placeholder(R.drawable.food_placeholder)
                .into(holder.image);

        holder.tvAdd.setOnClickListener(v -> {
            CartManager.getInstance().addFood(food);
            updateQuantityUI(holder, food);
            if (cartListener != null) {
                cartListener.onCartChanged();
            }
        });

        holder.btnPlus.setOnClickListener(v -> {
            CartManager.getInstance().addFood(food);
            updateQuantityUI(holder, food);
            if (cartListener != null) {
                cartListener.onCartChanged();
            }
        });

        holder.btnMinus.setOnClickListener(v -> {
            CartManager.getInstance().removeFood(food);
            updateQuantityUI(holder, food);
            if (cartListener != null) {
                cartListener.onCartChanged();
            }
        });

        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, FoodDetailActivity.class);
            intent.putExtra("food_name", food.getName());
            intent.putExtra("food_price", food.getPrice());
            intent.putExtra("food_image", food.getImage());
            context.startActivity(intent);
        });
    }

    private void updateQuantityUI(ViewHolder holder, Food food) {
        int quantity = CartManager.getInstance().getQuantity(food);
        if (quantity > 0) {
            holder.tvAdd.setVisibility(View.GONE);
            holder.layoutQuantity.setVisibility(View.VISIBLE);
            holder.tvQuantity.setText(String.valueOf(quantity));
        } else {
            holder.tvAdd.setVisibility(View.VISIBLE);
            holder.layoutQuantity.setVisibility(View.GONE);
        }
    }

    @Override
    public int getItemCount() {
        return foodList.size();
    }
}
