package com.example.foodiehub.activities;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.example.foodiehub.R;

public class MenuActivity extends AppCompatActivity {

    RecyclerView recyclerFoods;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        recyclerFoods = findViewById(R.id.recyclerFoods);
    }
}