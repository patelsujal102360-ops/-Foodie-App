package com.example.foodiehub.adapters;

import android.content.Context;
import android.graphics.Paint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.foodiehub.R;
import com.example.foodiehub.models.CartItem;
import com.example.foodiehub.utils.CartManager;

import java.util.List;

public class CartAdapter extends RecyclerView.Adapter<CartAdapter.ViewHolder> {

    private Context context;
    private List<CartItem> cartItems;
    private OnCartUpdateListener listener;

    public interface OnCartUpdateListener {
        void onCartUpdated();
    }

    public CartAdapter(Context context, List<CartItem> cartItems, OnCartUpdateListener listener) {
        this.context = context;
        this.cartItems = cartItems;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_cart, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        CartItem item = cartItems.get(position);
        holder.name.setText(item.getFood().getName());
        holder.price.setText("₹" + (item.getFood().getPrice() * item.getQuantity()));
        holder.originalPrice.setText("₹" + (item.getFood().getOriginalPrice() * item.getQuantity()));
        holder.originalPrice.setPaintFlags(holder.originalPrice.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
        holder.quantity.setText(String.valueOf(item.getQuantity()));
        
        holder.ivVeg.setVisibility(item.getFood().isVeg() ? View.VISIBLE : View.GONE);

        holder.btnPlus.setOnClickListener(v -> {
            CartManager.getInstance().addFood(item.getFood());
            notifyItemChanged(position);
            if (listener != null) listener.onCartUpdated();
        });

        holder.btnMinus.setOnClickListener(v -> {
            CartManager.getInstance().removeFood(item.getFood());
            if (CartManager.getInstance().getQuantity(item.getFood()) == 0) {
                notifyItemRemoved(position);
                notifyItemRangeChanged(position, cartItems.size());
            } else {
                notifyItemChanged(position);
            }
            if (listener != null) listener.onCartUpdated();
        });
    }

    @Override
    public int getItemCount() {
        return cartItems.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView name, price, originalPrice, quantity, btnMinus, btnPlus;
        ImageView ivVeg;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.tvCartFoodName);
            price = itemView.findViewById(R.id.tvCartFoodPrice);
            originalPrice = itemView.findViewById(R.id.tvOriginalPrice);
            quantity = itemView.findViewById(R.id.tvCartQuantity);
            btnMinus = itemView.findViewById(R.id.btnMinus);
            btnPlus = itemView.findViewById(R.id.btnPlus);
            ivVeg = itemView.findViewById(R.id.ivVeg);
        }
    }
}
