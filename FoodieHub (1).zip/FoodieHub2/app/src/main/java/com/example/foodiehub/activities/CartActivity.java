package com.example.foodiehub.activities;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.foodiehub.R;
import com.example.foodiehub.adapters.CartAdapter;
import com.example.foodiehub.utils.CartManager;

public class CartActivity extends AppCompatActivity {

    RecyclerView recyclerCart;
    TextView totalPrice;
    CartAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);

        recyclerCart = findViewById(R.id.recyclerCart);
        totalPrice = findViewById(R.id.totalPrice);

        recyclerCart.setLayoutManager(new LinearLayoutManager(this));
        adapter = new CartAdapter(this, CartManager.getInstance().getCartItems(), new CartAdapter.OnCartUpdateListener() {
            @Override
            public void onCartUpdated() {
                updateTotal();
            }
        });
        recyclerCart.setAdapter(adapter);

        updateTotal();
    }

    private void updateTotal() {
        totalPrice.setText("Total : ₹" + CartManager.getInstance().getTotalPrice());
    }
}