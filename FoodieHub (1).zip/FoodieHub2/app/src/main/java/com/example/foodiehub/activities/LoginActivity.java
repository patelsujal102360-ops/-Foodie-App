package com.example.foodiehub.activities;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.foodiehub.R;

public class LoginActivity extends AppCompatActivity {

    EditText phone, email, password;
    Button login;
    TextView signup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        phone = findViewById(R.id.phone);
        email = findViewById(R.id.email);
        password = findViewById(R.id.password);
        login = findViewById(R.id.login);
        signup = findViewById(R.id.signup);

        login.setOnClickListener(v -> {

            String ph = phone.getText().toString();
            String em = email.getText().toString();
            String pass = password.getText().toString();

            if (ph.isEmpty() || em.isEmpty() || pass.isEmpty()) {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            } else {
                // Save login status and timestamp
                SharedPreferences sharedPref = getSharedPreferences("FoodieHubPref", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPref.edit();
                editor.putBoolean("isLoggedIn", true);
                editor.putLong("loginTime", System.currentTimeMillis());
                editor.apply();

                startActivity(new Intent(this, MainActivity.class));
                finish();
            }

        });

        signup.setOnClickListener(v -> startActivity(new Intent(this, SignUpActivity.class)));
    }
}
