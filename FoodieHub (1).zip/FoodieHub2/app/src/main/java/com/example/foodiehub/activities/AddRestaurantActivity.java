package com.example.foodiehub.activities;

import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.foodiehub.R;
import com.example.foodiehub.models.Restaurant;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class AddRestaurantActivity extends AppCompatActivity {

    EditText etName, etImage, etRating, etDeliveryTime, etDistance, etOffer;
    CheckBox cbIsVeg;
    Button btnAddRestaurant;
    DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_restaurant);

        etName = findViewById(R.id.etName);
        etImage = findViewById(R.id.etImage);
        etRating = findViewById(R.id.etRating);
        etDeliveryTime = findViewById(R.id.etDeliveryTime);
        etDistance = findViewById(R.id.etDistance);
        etOffer = findViewById(R.id.etOffer);
        cbIsVeg = findViewById(R.id.cbIsVeg);
        btnAddRestaurant = findViewById(R.id.btnAddRestaurant);

        databaseReference = FirebaseDatabase.getInstance().getReference("Restaurants");

        btnAddRestaurant.setOnClickListener(v -> {
            saveRestaurant();
        });
    }

    private void saveRestaurant() {
        String name = etName.getText().toString().trim();
        String image = etImage.getText().toString().trim();
        String ratingStr = etRating.getText().toString().trim();
        String deliveryTime = etDeliveryTime.getText().toString().trim();
        String distance = etDistance.getText().toString().trim();
        String offer = etOffer.getText().toString().trim();
        boolean isVeg = cbIsVeg.isChecked();

        if (name.isEmpty() || image.isEmpty() || ratingStr.isEmpty()) {
            Toast.makeText(this, "Please fill required fields", Toast.LENGTH_SHORT).show();
            return;
        }

        float rating = Float.parseFloat(ratingStr);
        String id = databaseReference.push().getKey();

        // Using -1 for id in model for now, but we'll use Firebase key as the unique identifier
        // Actually, let's update the Restaurant model to use String ID for Firebase compatibility or handle it.
        // For simplicity, we'll store it as a Map or update the model.
        
        Restaurant restaurant = new Restaurant(0, name, image, rating, deliveryTime, distance, offer, isVeg);
        
        if (id != null) {
            databaseReference.child(id).setValue(restaurant)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        Toast.makeText(AddRestaurantActivity.this, "Restaurant Added", Toast.LENGTH_SHORT).show();
                        clearFields();
                    } else {
                        Toast.makeText(AddRestaurantActivity.this, "Failed to add", Toast.LENGTH_SHORT).show();
                    }
                });
        }
    }

    private void clearFields() {
        etName.setText("");
        etImage.setText("");
        etRating.setText("");
        etDeliveryTime.setText("");
        etDistance.setText("");
        etOffer.setText("");
        cbIsVeg.setChecked(false);
    }
}