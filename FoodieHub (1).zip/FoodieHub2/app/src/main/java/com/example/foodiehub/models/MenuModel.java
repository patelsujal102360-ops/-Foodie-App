package com.example.foodiehub.models;

public class MenuModel {
    public String name;
    public String price;
    public String category;

    public MenuModel(String name, String price, String category) {
        this.name = name;
        this.price = price;
        this.category = category;
    }
}