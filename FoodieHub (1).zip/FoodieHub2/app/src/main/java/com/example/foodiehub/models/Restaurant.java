package com.example.foodiehub.models;

public class Restaurant {

    private int id; // For local/legacy use
    private String firebaseId;
    private String name;
    private String image;
    private float rating;
    private String deliveryTime;
    private String distance;
    private String offer;
    private boolean isVeg;

    public Restaurant() {
        // Required for Firebase
    }

    public Restaurant(int id, String name, String image, float rating, String deliveryTime, String distance, String offer, boolean isVeg) {
        this.id = id;
        this.name = name;
        this.image = image;
        this.rating = rating;
        this.deliveryTime = deliveryTime;
        this.distance = distance;
        this.offer = offer;
        this.isVeg = isVeg;
    }

    public Restaurant(int id, String name, String image, float rating, String deliveryTime, boolean isVeg) {
        this.id = id;
        this.name = name;
        this.image = image;
        this.rating = rating;
        this.deliveryTime = deliveryTime;
        this.isVeg = isVeg;
    }

    public int getId() {
        return id;
    }

    public String getFirebaseId() {
        return firebaseId;
    }

    public void setFirebaseId(String firebaseId) {
        this.firebaseId = firebaseId;
    }

    public String getName() {
        return name;
    }

    public String getImage() {
        return image;
    }

    public float getRating() {
        return rating;
    }

    public String getDeliveryTime() {
        return deliveryTime;
    }

    public String getDistance() {
        return distance;
    }

    public String getOffer() {
        return offer;
    }

    public boolean isVeg() {
        return isVeg;
    }
}