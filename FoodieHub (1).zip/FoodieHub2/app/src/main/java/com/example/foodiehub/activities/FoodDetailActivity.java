package com.example.foodiehub.activities;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.foodiehub.R;

public class FoodDetailActivity extends AppCompatActivity {

    TextView foodName,foodPrice;
    Button addCart;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_food_detail);

        foodName=findViewById(R.id.foodName);
        foodPrice=findViewById(R.id.foodPrice);
        addCart=findViewById(R.id.addCart);

        addCart.setOnClickListener(v->{

            Toast.makeText(this,"Added to Cart",Toast.LENGTH_SHORT).show();

        });
    }
}