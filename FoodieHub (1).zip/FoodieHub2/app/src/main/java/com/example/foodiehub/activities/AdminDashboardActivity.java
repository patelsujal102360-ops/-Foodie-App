package com.example.foodiehub.activities;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.example.foodiehub.R;

public class AdminDashboardActivity extends AppCompatActivity {

    Button addRestaurant,addFood;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_dashboard);

        addRestaurant=findViewById(R.id.addRestaurant);
        addFood=findViewById(R.id.addFood);

        addRestaurant.setOnClickListener(v->{

            startActivity(new Intent(this,AddRestaurantActivity.class));

        });

        addFood.setOnClickListener(v->{

            startActivity(new Intent(this,AddFoodActivity.class));

        });
    }
}