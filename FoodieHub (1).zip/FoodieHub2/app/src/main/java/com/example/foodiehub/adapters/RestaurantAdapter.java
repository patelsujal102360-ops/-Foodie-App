package com.example.foodiehub.adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.foodiehub.R;
import com.example.foodiehub.activities.RestaurantActivity;
import com.example.foodiehub.models.Restaurant;

import java.util.ArrayList;

public class RestaurantAdapter extends RecyclerView.Adapter<RestaurantAdapter.ViewHolder>{

    Context context;
    ArrayList<Restaurant> list;

    public RestaurantAdapter(Context context, ArrayList<Restaurant> list){
        this.context = context;
        this.list = list;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType){
        View view = LayoutInflater.from(context).inflate(R.layout.item_restaurant, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position){
        Restaurant restaurant = list.get(position);

        holder.name.setText(restaurant.getName());
        holder.rating.setText(String.valueOf(restaurant.getRating()));
        holder.deliveryInfo.setText("Schedule for later");
        holder.offer.setText(restaurant.getOffer());
        
        if (restaurant.isVeg()) {
            holder.vegBadge.setVisibility(View.VISIBLE);
        } else {
            holder.vegBadge.setVisibility(View.GONE);
        }

        Glide.with(context)
                .load(restaurant.getImage())
                .placeholder(android.R.drawable.ic_menu_gallery)
                .into(holder.image);

        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, RestaurantActivity.class);
            intent.putExtra("restaurant_name", restaurant.getName());
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount(){
        return list.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder{
        TextView name, rating, deliveryInfo, offer, vegBadge;
        ImageView image;

        public ViewHolder(View itemView){
            super(itemView);
            name = itemView.findViewById(R.id.restaurantName);
            rating = itemView.findViewById(R.id.restaurantRating);
            image = itemView.findViewById(R.id.restaurantImage);
            deliveryInfo = itemView.findViewById(R.id.tvDeliveryInfo);
            offer = itemView.findViewById(R.id.tvOffer);
            vegBadge = itemView.findViewById(R.id.tvVegBadge);
        }
    }
}