package com.example.foodiehub.activities;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.foodiehub.R;
import com.example.foodiehub.models.Food;
import com.example.foodiehub.models.Restaurant;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class AddFoodActivity extends AppCompatActivity {

    EditText etFoodName, etFoodCategory, etFoodPrice, etOriginalPrice, etFoodImage, etFoodDescription;
    CheckBox cbIsVeg, cbIsSpicy, cbHighlyReordered;
    Spinner spinnerRestaurants;
    Button btnAddFood, btnSelectImage;
    ImageView ivFoodImage;
    ProgressBar progressBar;

    DatabaseReference dbRestaurants, dbFoods;
    StorageReference storageReference;
    List<String> restaurantNames;
    List<String> restaurantIds;
    Uri imageUri;

    private final ActivityResultLauncher<Intent> imagePickerLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                    imageUri = result.getData().getData();
                    ivFoodImage.setImageURI(imageUri);
                }
            }
    );

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_food);

        etFoodName = findViewById(R.id.etFoodName);
        etFoodCategory = findViewById(R.id.etFoodCategory);
        etFoodPrice = findViewById(R.id.etFoodPrice);
        etOriginalPrice = findViewById(R.id.etOriginalPrice);
        etFoodImage = findViewById(R.id.etFoodImage);
        etFoodDescription = findViewById(R.id.etFoodDescription);
        cbIsVeg = findViewById(R.id.cbIsVeg);
        cbIsSpicy = findViewById(R.id.cbIsSpicy);
        cbHighlyReordered = findViewById(R.id.cbHighlyReordered);
        spinnerRestaurants = findViewById(R.id.spinnerRestaurants);
        btnAddFood = findViewById(R.id.btnAddFood);
        btnSelectImage = findViewById(R.id.btnSelectImage);
        ivFoodImage = findViewById(R.id.ivFoodImage);
        progressBar = findViewById(R.id.progressBar);

        dbRestaurants = FirebaseDatabase.getInstance().getReference("Restaurants");
        dbFoods = FirebaseDatabase.getInstance().getReference("Foods");
        storageReference = FirebaseStorage.getInstance().getReference("food_images");

        restaurantNames = new ArrayList<>();
        restaurantIds = new ArrayList<>();

        loadRestaurants();

        btnSelectImage.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            imagePickerLauncher.launch(intent);
        });

        btnAddFood.setOnClickListener(v -> {
            if (imageUri != null) {
                uploadImageAndSaveFood();
            } else {
                saveFood(etFoodImage.getText().toString().trim());
            }
        });
    }

    private void loadRestaurants() {
        dbRestaurants.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (!snapshot.exists()) {
                    Toast.makeText(AddFoodActivity.this, "No restaurants found", Toast.LENGTH_SHORT).show();
                    return;
                }
                restaurantNames.clear();
                restaurantIds.clear();
                for (DataSnapshot postSnapshot : snapshot.getChildren()) {
                    try {
                        Restaurant restaurant = postSnapshot.getValue(Restaurant.class);
                        if (restaurant != null) {
                            String name = restaurant.getName() != null ? restaurant.getName() : "Unknown";
                            restaurantNames.add(name);
                            restaurantIds.add(postSnapshot.getKey());
                        }
                    } catch (Exception e) {
                        // Skip invalid data
                    }
                }
                if (restaurantNames.isEmpty()) {
                    Toast.makeText(AddFoodActivity.this, "No valid restaurants", Toast.LENGTH_SHORT).show();
                    return;
                }
                ArrayAdapter<String> adapter = new ArrayAdapter<>(AddFoodActivity.this, android.R.layout.simple_spinner_item, restaurantNames);
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                spinnerRestaurants.setAdapter(adapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(AddFoodActivity.this, "Failed to load restaurants", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void uploadImageAndSaveFood() {
        progressBar.setVisibility(View.VISIBLE);
        btnAddFood.setEnabled(false);
        StorageReference fileRef = storageReference.child(UUID.randomUUID().toString());
        fileRef.putFile(imageUri).addOnSuccessListener(taskSnapshot -> 
            fileRef.getDownloadUrl().addOnSuccessListener(uri -> saveFood(uri.toString()))
        ).addOnFailureListener(e -> {
            progressBar.setVisibility(View.GONE);
            btnAddFood.setEnabled(true);
            Toast.makeText(AddFoodActivity.this, "Image upload failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        });
    }

    private void saveFood(String imageUrl) {
        if (restaurantIds.isEmpty()) {
            Toast.makeText(this, "Select a restaurant first", Toast.LENGTH_SHORT).show();
            progressBar.setVisibility(View.GONE);
            btnAddFood.setEnabled(true);
            return;
        }

        String name = etFoodName.getText().toString().trim();
        String category = etFoodCategory.getText().toString().trim();
        String priceStr = etFoodPrice.getText().toString().trim();
        String originalPriceStr = etOriginalPrice.getText().toString().trim();
        String description = etFoodDescription.getText().toString().trim();
        boolean isVeg = cbIsVeg.isChecked();
        boolean isSpicy = cbIsSpicy.isChecked();
        boolean isHighlyReordered = cbHighlyReordered.isChecked();
        int selectedPosition = spinnerRestaurants.getSelectedItemPosition();
        
        if (selectedPosition == -1) {
            Toast.makeText(this, "Select a restaurant", Toast.LENGTH_SHORT).show();
            progressBar.setVisibility(View.GONE);
            btnAddFood.setEnabled(true);
            return;
        }
        
        String restaurantId = restaurantIds.get(selectedPosition);

        if (name.isEmpty() || category.isEmpty() || priceStr.isEmpty() || imageUrl.isEmpty()) {
            Toast.makeText(this, "Name, Category, Price and Image are required", Toast.LENGTH_SHORT).show();
            progressBar.setVisibility(View.GONE);
            btnAddFood.setEnabled(true);
            return;
        }

        try {
            int price = Integer.parseInt(priceStr);
            int originalPrice = originalPriceStr.isEmpty() ? price : Integer.parseInt(originalPriceStr);

            progressBar.setVisibility(View.VISIBLE);
            btnAddFood.setEnabled(false);
            
            String id = dbFoods.push().getKey();
            Food food = new Food(0, restaurantId, name, price, originalPrice, imageUrl, description, isVeg, isSpicy, isHighlyReordered, category);
            food.setFirebaseId(id);

            if (id != null) {
                dbFoods.child(id).setValue(food).addOnCompleteListener(task -> {
                    progressBar.setVisibility(View.GONE);
                    btnAddFood.setEnabled(true);
                    if (task.isSuccessful()) {
                        Toast.makeText(AddFoodActivity.this, "Food Added", Toast.LENGTH_SHORT).show();
                        clearFields();
                    } else {
                        Toast.makeText(AddFoodActivity.this, "Failed to add", Toast.LENGTH_SHORT).show();
                    }
                });
            }
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Invalid price format", Toast.LENGTH_SHORT).show();
            progressBar.setVisibility(View.GONE);
            btnAddFood.setEnabled(true);
        }
    }

    private void clearFields() {
        etFoodName.setText("");
        etFoodCategory.setText("");
        etFoodPrice.setText("");
        etOriginalPrice.setText("");
        etFoodImage.setText("");
        etFoodDescription.setText("");
        cbIsVeg.setChecked(false);
        cbIsSpicy.setChecked(false);
        cbHighlyReordered.setChecked(false);
        ivFoodImage.setImageResource(android.R.drawable.ic_menu_gallery);
        imageUri = null;
    }
}
