package com.example.foodiehub.utils;

import com.example.foodiehub.models.CartItem;
import com.example.foodiehub.models.Food;

import java.util.ArrayList;
import java.util.List;

public class CartManager {
    private static CartManager instance;
    private List<CartItem> cartItems;

    private CartManager() {
        cartItems = new ArrayList<>();
    }

    public static synchronized CartManager getInstance() {
        if (instance == null) {
            instance = new CartManager();
        }
        return instance;
    }

    public void addFood(Food food) {
        for (CartItem item : cartItems) {
            if (item.getFood().getId() == food.getId()) {
                item.setQuantity(item.getQuantity() + 1);
                return;
            }
        }
        cartItems.add(new CartItem(food, 1));
    }

    public void removeFood(Food food) {
        for (int i = 0; i < cartItems.size(); i++) {
            CartItem item = cartItems.get(i);
            if (item.getFood().getId() == food.getId()) {
                if (item.getQuantity() > 1) {
                    item.setQuantity(item.getQuantity() - 1);
                } else {
                    cartItems.remove(i);
                }
                return;
            }
        }
    }

    public int getQuantity(Food food) {
        for (CartItem item : cartItems) {
            if (item.getFood().getId() == food.getId()) {
                return item.getQuantity();
            }
        }
        return 0;
    }

    public List<CartItem> getCartItems() {
        return cartItems;
    }

    public int getTotalPrice() {
        int total = 0;
        for (CartItem item : cartItems) {
            total += item.getFood().getPrice() * item.getQuantity();
        }
        return total;
    }

    public int getCartCount() {
        int count = 0;
        for (CartItem item : cartItems) {
            count += item.getQuantity();
        }
        return count;
    }

    public void clearCart() {
        cartItems.clear();
    }
}