package com.example.foodiehub.models;

public class Food {

    private int id;
    private String firebaseId;
    private String restaurantId;
    private String name;
    private int price;
    private int originalPrice;
    private String image;
    private String description;
    private boolean isVeg;
    private boolean isSpicy;
    private boolean isHighlyReordered;
    private String category;

    public Food() {
        // Required for Firebase
    }

    public Food(int id, String restaurantId, String name, int price, int originalPrice, String image, String description, boolean isVeg, boolean isSpicy, boolean isHighlyReordered, String category) {
        this.id = id;
        this.restaurantId = restaurantId;
        this.name = name;
        this.price = price;
        this.originalPrice = originalPrice;
        this.image = image;
        this.description = description;
        this.isVeg = isVeg;
        this.isSpicy = isSpicy;
        this.isHighlyReordered = isHighlyReordered;
        this.category = category;
    }

    public Food(int id, String name, int price, String category, String image) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.category = category;
        this.image = image;
        this.originalPrice = price + 20; // Default original price
        this.isVeg = true;
        this.description = "Delicious " + name + " from our " + category + " menu.";
    }

    public Food(int id, String name, int price, String category) {
        this(id, name, price, category, null);
    }

    public String getCategory() {
        return category;
    }

    public int getId() {
        return id;
    }

    public String getFirebaseId() {
        return firebaseId;
    }

    public void setFirebaseId(String firebaseId) {
        this.firebaseId = firebaseId;
    }

    public String getRestaurantId() {
        return restaurantId;
    }

    public String getName() {
        return name;
    }

    public int getPrice() {
        return price;
    }

    public int getOriginalPrice() {
        return originalPrice;
    }

    public String getImage() {
        return image;
    }

    public String getDescription() {
        return description;
    }

    public boolean isVeg() {
        return isVeg;
    }

    public boolean isSpicy() {
        return isSpicy;
    }

    public boolean isHighlyReordered() {
        return isHighlyReordered;
    }
}