package com.example.foodiehub.activities;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;

import androidx.appcompat.app.AppCompatActivity;

import com.example.foodiehub.R;

public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        new Handler().postDelayed(() -> {
            SharedPreferences sharedPref = getSharedPreferences("FoodieHubPref", Context.MODE_PRIVATE);
            boolean isLoggedIn = sharedPref.getBoolean("isLoggedIn", false);
            long loginTime = sharedPref.getLong("loginTime", 0);
            
            long currentTime = System.currentTimeMillis();
            long oneYearInMillis = 365L * 24 * 60 * 60 * 1000;

            if (isLoggedIn && (currentTime - loginTime < oneYearInMillis)) {
                // Still within the one-year window
                startActivity(new Intent(this, MainActivity.class));
            } else {
                // Not logged in or session expired after a year
                startActivity(new Intent(this, LoginActivity.class));
            }
            finish();

        }, 2000);
    }
}